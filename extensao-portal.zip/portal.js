// Na tela "Lançamento de Frequência" do Portal do Professor: preenche presença/falta com a chamada do Aula por IA.
// Só clica nos quadradinhos (como o professor faria); quem salva é o professor, no botão "Salvar" do portal.
(function () {
  const form = document.getElementById('horaAulaCommand');
  if (!form) { if (document.getElementById('accordion')) conteudoNaAgenda(); return; }

  const texto = function (el) { return (el && el.textContent || '').replace(/\s+/g, ' ').trim(); };
  const campo = function (rotulo) {
    const lbl = Array.prototype.filter.call(document.querySelectorAll('.topo-informacoes span.label'), function (s) { return texto(s).indexOf(rotulo) === 0; })[0];
    return lbl ? texto(lbl.parentNode).replace(rotulo, '').trim() : '';
  };
  const disciplina = campo('Disciplina:'), data = campo('Horário de Aula:');
  const cartoes = Array.prototype.slice.call(form.querySelectorAll('div.aluno'));
  const nomeDe = function (c) { return texto(c.querySelector('a.nome-aluno')); };

  // situação de um quadradinho, como o próprio portal lê
  const situacao = function (q) {
    const c = q.className;
    if (c.indexOf('aluno-ausente-local') !== -1) return 'falta';
    if (c.indexOf('aluno-presente-local') !== -1 || c.indexOf('aluno-ad-local') !== -1) return 'presente';
    return 'branco';
  };
  // só os quadradinhos que o portal deixa mudar (falta justificada / atendimento domiciliar ficam de fora)
  const editaveis = function (c) {
    return Array.prototype.filter.call(c.querySelectorAll('td.periodos > div'), function (q) { return q.classList.contains('periodoLocal') && !q.classList.contains('aluno-ad-local'); });
  };
  const marcar = function (q, alvo) {
    for (let i = 0; i < 3 && situacao(q) !== alvo; i++) q.click();   // branco → presente → falta → presente…
    return situacao(q) === alvo;
  };

  // caixa da extensão, no topo da área de frequência
  const caixa = document.createElement('div');
  caixa.style.cssText = 'margin:8px 7px;padding:10px 12px;border:2px solid #1f3a93;border-radius:8px;background:#eef2ff;font:13px Arial,sans-serif;color:#13235b';
  caixa.innerHTML = '<b>Aula por IA</b> · ' + data + '<br><button type="button" id="aiaPreencher" style="margin-top:6px;padding:5px 12px;font-weight:bold;cursor:pointer">Preencher com a chamada do Aula por IA</button>' +
    '<div id="aiaMsg" style="margin-top:6px"></div>';
  const corpo = document.querySelector('.corpopage') || form.parentNode;
  corpo.insertBefore(caixa, corpo.firstChild);
  const msg = function (h) { document.getElementById('aiaMsg').innerHTML = h; };
  let aulaPreenchida = null;

  document.getElementById('aiaPreencher').addEventListener('click', function () {
    const bt = this; bt.disabled = true; msg('Buscando a chamada no Aula por IA…');
    chrome.runtime.sendMessage({ tipo: 'api', acao: 'portalAula', dados: { disciplina: disciplina, data: data, nomes: cartoes.map(nomeDe) } }, function (r) {
      bt.disabled = false;
      if (!r || !r.ok) {
        msg(r && (r.erro === 'SEM_LOGIN' || r.erro === 'SESSAO')
          ? '⚠ Abra o <b>Aula por IA</b> (miguelmeirelles-oss.github.io) neste Chrome, já logado, e depois volte aqui e clique de novo.'
          : '⚠ ' + ((r && r.erro) || 'Não deu para falar com o Aula por IA.'));
        return;
      }
      const a = r.resultado;
      if (!a.encontrada) { msg('Não há aula de <b>' + a.disciplina + '</b> em ' + a.data + ' no Aula por IA. <b>Nada foi marcado.</b>'); return; }
      let pres = 0, falt = 0;
      const branco = [], travados = [];
      cartoes.forEach(function (c) {
        const nome = nomeDe(c), estado = a.estados[nome], qs = editaveis(c);
        c.style.outline = '';
        if (!qs.length) { travados.push(nome); return; }   // já vem preenchido pelo portal (ex.: falta justificada)
        if (estado !== 'presente' && estado !== 'falta') { branco.push(nome); c.style.outline = '3px solid orange'; return; }
        const ok = qs.map(function (q) { return marcar(q, estado); }).every(Boolean);
        if (!ok) { branco.push(nome); c.style.outline = '3px solid orange'; return; }
        if (estado === 'falta') { falt++; c.style.outline = '3px solid #c62828'; } else pres++;
      });
      aulaPreenchida = a.aulaId;
      msg('✓ Aula ' + a.numero + ' de ' + a.disciplina + ': <b>' + pres + ' presente(s)</b> e <b>' + falt + ' falta(s)</b> marcadas (as faltas estão com borda vermelha).' +
        (travados.length ? '<br>Não mexi (já vinham preenchidos pelo portal): ' + travados.join(', ') + '.' : '') +
        (branco.length ? '<br><b style="color:#b35c00">Deixei em branco (borda laranja), sem chamada no Aula por IA:</b> ' + branco.join(', ') + '. Marque à mão.' : '') +
        (a.semCorrespondencia.length ? '<br>Alunos do Aula por IA que não achei nesta lista do portal: ' + a.semCorrespondencia.join(', ') + '.' : '') +
        (a.maisDeUma ? '<br>Há mais de uma aula neste dia no Aula por IA; usei a aula ' + a.numero + '.' : '') +
        '<br><b>Confira e clique em "Salvar" do portal.</b>');
    });
  });

  // ao salvar no portal, marca "faltas lançadas" no Diário do portal do Aula por IA
  const salvar = document.getElementById('enviar');
  if (salvar) salvar.addEventListener('click', function () {
    if (!aulaPreenchida) return;
    if (form.querySelector('.periodoLocal.aluno-branco-local')) return;   // o portal não salva com alguém em branco
    const pres = form.querySelectorAll('div.aluno').length, falt = Array.prototype.filter.call(form.querySelectorAll('div.aluno'), function (c) { return c.querySelector('.aluno-ausente-local'); }).length;
    chrome.runtime.sendMessage({ tipo: 'api', acao: 'salvarDiario', dados: { aulaId: aulaPreenchida, campos: { faltasOk: true,
      portal: { freq: '✓ frequência salva pela tela da aula (' + (pres - falt) + ' presença(s), ' + falt + ' falta(s))', semMarcar: [] } } } });
  });

  // ---- Agenda da Turma: janela "Conteúdo Ministrado na Aula" (o "Sem Registro") ----
  function conteudoNaAgenda() {
    const MESES = { janeiro: '01', fevereiro: '02', 'março': '03', marco: '03', abril: '04', maio: '05', junho: '06', julho: '07', agosto: '08', setembro: '09', outubro: '10', novembro: '11', dezembro: '12' };
    const txt = function (el) { return (el && el.textContent || '').replace(/\s+/g, ' ').trim(); };
    const lbl = Array.prototype.filter.call(document.querySelectorAll('.topo-informacoes span.label'), function (s) { return txt(s).indexOf('Disciplina:') === 0; })[0];
    const disciplina = lbl ? txt(lbl.parentNode).replace('Disciplina:', '').trim() : '';
    let aulaDoConteudo = null;
    // aviso na agenda: mostra que a extensão está ligada e onde ela aparece
    const aviso = document.createElement('div');
    aviso.style.cssText = 'margin:6px 7px;padding:6px 10px;border:2px solid #1f3a93;border-radius:6px;background:#eef2ff;font:12px Arial,sans-serif;color:#13235b';
    aviso.innerHTML = '<b>Aula por IA ligado.</b> Clique na <b>setinha verde</b> da aula para preencher a frequência, ou em <b>Sem Registro</b> para preencher o conteúdo ministrado.';
    const alvoAviso = document.querySelector('.corpopage');
    if (alvoAviso) alvoAviso.insertBefore(aviso, alvoAviso.firstChild);
    const prepararJanela = function () {
      const dlg = document.getElementById('dialog-conteudo-ministrado'), ta = document.getElementById('conteudoMinistrado');
      if (!dlg || !ta || ta.readOnly || dlg.offsetParent === null) return;
      const titulo = txt(document.getElementById('ui-dialog-title-dialog-conteudo-ministrado'));
      if (dlg.dataset.aiaTitulo === titulo) return;   // já preparada para esta aula
      dlg.dataset.aiaTitulo = titulo; aulaDoConteudo = null;
      const velho = document.getElementById('aiaConteudo'); if (velho) velho.remove();
      const m = titulo.match(/(\d{1,2}) de ([A-Za-zçÇ]+) \/ (\d{4})/);
      const caixa = document.createElement('div');
      caixa.id = 'aiaConteudo';
      caixa.style.cssText = 'margin:0 0 6px;padding:6px 8px;border:2px solid #1f3a93;border-radius:6px;background:#eef2ff;font:12px Arial,sans-serif;color:#13235b';
      caixa.innerHTML = '<b>Aula por IA</b> <button type="button" id="aiaTema" style="margin-left:6px;cursor:pointer">Preencher com o tema da aula</button><span id="aiaTemaMsg" style="margin-left:6px"></span>';
      dlg.insertBefore(caixa, dlg.firstChild);
      document.getElementById('aiaTema').addEventListener('click', function () {
        const msgT = document.getElementById('aiaTemaMsg');
        if (!m || !MESES[m[2].toLowerCase()]) { msgT.textContent = 'Não entendi a data desta aula.'; return; }
        const data = ('0' + m[1]).slice(-2) + '/' + MESES[m[2].toLowerCase()] + '/' + m[3];
        this.disabled = true; msgT.textContent = 'Buscando…';
        const bt = this;
        chrome.runtime.sendMessage({ tipo: 'api', acao: 'portalAula', dados: { disciplina: disciplina, data: data, nomes: [] } }, function (r) {
          bt.disabled = false;
          if (!r || !r.ok) { msgT.innerHTML = r && (r.erro === 'SEM_LOGIN' || r.erro === 'SESSAO') ? 'Abra o Aula por IA neste Chrome, já logado, e tente de novo.' : '⚠ ' + ((r && r.erro) || 'Sem conexão com o Aula por IA.'); return; }
          const a = r.resultado;
          if (!a.encontrada) { msgT.textContent = 'Não há aula de ' + a.disciplina + ' em ' + a.data + ' no Aula por IA.'; return; }
          if (!a.conteudo) { msgT.textContent = 'A aula ' + a.numero + ' ainda não tem tema/ata no Aula por IA.'; return; }
          if (ta.value.trim() && !confirm('Já tem texto aqui. Trocar pelo tema do Aula por IA?')) { msgT.textContent = ''; return; }
          ta.value = a.conteudo;
          ta.dispatchEvent(new Event('keyup', { bubbles: true }));
          aulaDoConteudo = a.aulaId;
          msgT.innerHTML = '✓ Tema da aula ' + a.numero + '. <b>Confira e clique em Salvar.</b>';
        });
      });
    };
    new MutationObserver(prepararJanela).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style'] });
    // ao salvar a janela, marca "conteúdo lançado" no Diário do portal do Aula por IA
    document.addEventListener('click', function (ev) {
      const b = ev.target.closest && ev.target.closest('.ui-dialog-buttonpane button');
      if (!b || !aulaDoConteudo || txt(b) !== 'Salvar') return;
      const dialogo = b.closest('.ui-dialog');
      if (!dialogo || !dialogo.querySelector('#dialog-conteudo-ministrado')) return;
      chrome.runtime.sendMessage({ tipo: 'api', acao: 'salvarDiario', dados: { aulaId: aulaDoConteudo, campos: { conteudoOk: true } } });
      aulaDoConteudo = null;
    }, true);
  }
})();
