// Agenda da Turma do Portal do Professor: preenche em lote, data por data, a frequência e o conteúdo ministrado
// das aulas que existem no Aula por IA (mesma data). Usa as próprias telas do portal (como se o professor clicasse)
// e salva cada uma. Datas sem aula no Aula por IA não são mexidas nem criadas. No fim, um relatório para baixar.
(function () {
  if (!document.getElementById('accordion')) return;
  const txt = function (el) { return (el && el.textContent || '').replace(/\s+/g, ' ').trim(); };
  const esperar = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  const ate = async function (cond, ms) { const t0 = Date.now(); while (Date.now() - t0 < (ms || 15000)) { try { const v = cond(); if (v) return v; } catch (e) {} await esperar(200); } return null; };
  const api = function (acao, dados) {
    return new Promise(function (ok, falha) {
      chrome.runtime.sendMessage({ tipo: 'api', acao: acao, dados: dados }, function (r) {
        if (r && r.ok) ok(r.resultado);
        else falha(new Error(r && (r.erro === 'SEM_LOGIN' || r.erro === 'SESSAO') ? 'Abra o Aula por IA neste Chrome, já logado, e tente de novo.' : (r && r.erro) || 'Sem conexão com o Aula por IA.'));
      });
    });
  };
  const lbl = Array.prototype.filter.call(document.querySelectorAll('.topo-informacoes span.label'), function (s) { return txt(s).indexOf('Disciplina:') === 0; })[0];
  const disciplina = lbl ? txt(lbl.parentNode).replace('Disciplina:', '').trim() : '';

  // ---- caixa do lote (abaixo do aviso "Aula por IA ligado")
  const caixa = document.createElement('div');
  caixa.style.cssText = 'margin:6px 7px;padding:8px 10px;border:2px solid #1f3a93;border-radius:6px;background:#f6f8ff;font:12px Arial,sans-serif;color:#13235b';
  caixa.innerHTML = '<b>Preencher o semestre todo</b> (frequência e conteúdo ministrado das datas que batem com o Aula por IA; cada uma é salva no portal):<br>' +
    '<button type="button" id="aiaLoteBrancos" style="margin:6px 6px 0 0;cursor:pointer;font-weight:bold">Preencher só o que está em branco</button>' +
    '<button type="button" id="aiaLoteTudo" style="margin:6px 6px 0 0;cursor:pointer">Preencher tudo de novo</button>' +
    '<button type="button" id="aiaLoteParar" style="margin:6px 6px 0 0;cursor:pointer;display:none">Parar</button>' +
    '<button type="button" id="aiaLoteCfgBt" style="margin:6px 0 0 0;cursor:pointer" title="Escolher o que preencher e os meses">⚙ Configurar</button>' +
    '<span id="aiaLoteResumo" style="margin-left:6px;color:#555"></span>' +
    '<div id="aiaLoteCfg" style="display:none;margin-top:8px;padding:8px;border:1px solid #c9d2f0;border-radius:6px;background:#fff"></div>' +
    '<div id="aiaLoteMsg" style="margin-top:6px"></div><div id="aiaLoteRel"></div>';
  const corpo = document.querySelector('.corpopage');
  if (!corpo) return;
  corpo.insertBefore(caixa, corpo.children[1] || null);
  const msg = function (h) { document.getElementById('aiaLoteMsg').innerHTML = h; };
  let parar = false;

  // ---- configuração (fica guardada neste Chrome): o que preencher e quais meses
  let cfg = { freq: true, cont: true, meses: null };   // meses: null = todos; senão lista de "2026_10"…
  const meses = function () { return Array.prototype.map.call(document.querySelectorAll('#accordion a.mesesAccordion'), function (a) { return { id: a.getAttribute('anomes'), nome: txt(a) }; }); };
  const mesLigado = function (id) { return !cfg.meses || cfg.meses.indexOf(id) !== -1; };
  const resumoCfg = function () {
    const ms = meses(), lig = ms.filter(function (m) { return mesLigado(m.id); });
    document.getElementById('aiaLoteResumo').textContent = '(' + [cfg.freq ? 'frequência' : '', cfg.cont ? 'conteúdo' : ''].filter(String).join(' e ') +
      ' · ' + (lig.length === ms.length ? 'todos os meses' : lig.map(function (m) { return m.nome.replace(/ \/ \d{4}/, ''); }).join(', ') || 'nenhum mês') + ')';
  };
  const desenharCfg = function () {
    const box = document.getElementById('aiaLoteCfg');
    box.innerHTML = '<b>O que preencher</b><br>' +
      '<label style="cursor:pointer"><input type="checkbox" id="aiaCfgFreq"' + (cfg.freq ? ' checked' : '') + '> Frequência (presenças e faltas)</label><br>' +
      '<label style="cursor:pointer"><input type="checkbox" id="aiaCfgCont"' + (cfg.cont ? ' checked' : '') + '> Conteúdo ministrado (tema da aula)</label><br>' +
      '<b style="display:inline-block;margin-top:6px">Meses</b> <a href="#" id="aiaCfgTodos" style="font-size:11px">todos</a> · <a href="#" id="aiaCfgNenhum" style="font-size:11px">nenhum</a><br>' +
      meses().map(function (m) { return '<label style="cursor:pointer;margin-right:10px"><input type="checkbox" data-aiames="' + m.id + '"' + (mesLigado(m.id) ? ' checked' : '') + '> ' + m.nome + '</label>'; }).join('') +
      '<div style="margin-top:6px"><button type="button" id="aiaCfgOk" style="cursor:pointer">OK</button></div>';
    const ler = function () {
      cfg.freq = document.getElementById('aiaCfgFreq').checked; cfg.cont = document.getElementById('aiaCfgCont').checked;
      const marc = Array.prototype.filter.call(box.querySelectorAll('[data-aiames]'), function (c) { return c.checked; }).map(function (c) { return c.dataset.aiames; });
      cfg.meses = marc.length === meses().length ? null : marc;
      try { chrome.storage.local.set({ cfgLote: cfg }); } catch (e) {}
      resumoCfg();
    };
    box.querySelectorAll('input').forEach(function (c) { c.addEventListener('change', ler); });
    document.getElementById('aiaCfgTodos').addEventListener('click', function (e) { e.preventDefault(); box.querySelectorAll('[data-aiames]').forEach(function (c) { c.checked = true; }); ler(); });
    document.getElementById('aiaCfgNenhum').addEventListener('click', function (e) { e.preventDefault(); box.querySelectorAll('[data-aiames]').forEach(function (c) { c.checked = false; }); ler(); });
    document.getElementById('aiaCfgOk').addEventListener('click', function () { box.style.display = 'none'; });
  };
  document.getElementById('aiaLoteCfgBt').addEventListener('click', function () {
    const box = document.getElementById('aiaLoteCfg');
    if (box.style.display === 'none') { desenharCfg(); box.style.display = ''; } else box.style.display = 'none';
  });
  try { chrome.storage.local.get('cfgLote').then(function (g) { if (g.cfgLote) cfg = Object.assign(cfg, g.cfgLote); resumoCfg(); }); } catch (e) { resumoCfg(); }
  resumoCfg();

  // ---- abre todos os meses (o portal carrega cada mês quando a gente clica nele)
  async function carregarMeses() {
    const links = Array.prototype.slice.call(document.querySelectorAll('#accordion a.mesesAccordion'));
    for (let i = 0; i < links.length; i++) {
      const a = links[i], id = 'conteudoAccordion' + a.getAttribute('ano') + a.getAttribute('mes');
      if (!mesLigado(a.getAttribute('anomes')) || document.getElementById(id)) continue;
      msg('Abrindo ' + txt(a) + '…');
      a.parentNode.click();
      await ate(function () { return document.getElementById(id); }, 20000);
      await esperar(300);
    }
  }
  function linhas() {
    return Array.prototype.filter.call(document.querySelectorAll('#accordion tr.row[idagenda]'), function (tr) { return mesLigado(tr.getAttribute('dataaccordion')); }).map(function (tr) {
      const am = String(tr.getAttribute('dataaccordion') || '').split('_');   // "2026_10" = novembro (mês começa em 0)
      const mes = ('0' + (Number(am[1]) + 1)).slice(-2), dia = ('0' + Number(tr.getAttribute('data'))).slice(-2);
      const tds = tr.querySelectorAll('td'), cont = tr.querySelector('a.add-cont-min');
      return { tr: tr, id: tr.getAttribute('idagenda'), data: dia + '/' + mes + '/' + am[0],
        freqUrl: (tr.querySelector('a[title="Lançamento de Frequência"]') || {}).href || '',
        freqLancada: !/não lançada/i.test(txt(tds[3])), cont: cont, contVazio: !cont || txt(cont) === 'Sem Registro' };
    });
  }

  // ---- frequência de uma data: abre a tela do portal escondida, marca e salva
  const situacao = function (q) {
    const c = q.className;
    if (c.indexOf('aluno-ausente-local') !== -1) return 'falta';
    if (c.indexOf('aluno-presente-local') !== -1 || c.indexOf('aluno-ad-local') !== -1) return 'presente';
    return 'branco';
  };
  async function frequencia(l) {
    const fr = document.createElement('iframe');
    fr.style.cssText = 'position:absolute;width:1000px;height:600px;left:-3000px;top:0';
    document.body.appendChild(fr);
    try {
      fr.src = l.freqUrl;
      const doc = await ate(function () { const d = fr.contentDocument; return d && d.readyState === 'complete' && d.getElementById('horaAulaCommand') && fr.contentWindow.jQuery && d; }, 25000);
      if (!doc) return { erro: 'a tela de frequência não abriu' };
      await esperar(400);   // o portal termina de ligar os quadradinhos
      const cartoes = Array.prototype.slice.call(doc.querySelectorAll('#horaAulaCommand div.aluno'));
      const nome = function (c) { return txt(c.querySelector('a.nome-aluno')); };
      const a = await api('portalAula', { disciplina: disciplina, data: l.data, nomes: cartoes.map(nome) });
      if (!a.encontrada) return { semAula: true };
      let pres = 0, falt = 0;
      const branco = [];
      cartoes.forEach(function (c) {
        const qs = Array.prototype.filter.call(c.querySelectorAll('td.periodos > div'), function (q) { return q.classList.contains('periodoLocal') && !q.classList.contains('aluno-ad-local'); });
        if (!qs.length) return;   // justificada / já travada pelo portal: não mexe
        const alvo = a.estados[nome(c)];
        if (alvo !== 'presente' && alvo !== 'falta') { if (qs.some(function (q) { return situacao(q) === 'branco'; })) branco.push(nome(c)); return; }
        qs.forEach(function (q) { for (let i = 0; i < 3 && situacao(q) !== alvo; i++) q.click(); });
        if (alvo === 'falta') falt++; else pres++;
      });
      if (branco.length) return { aula: a, incompleto: branco };   // o portal não salva com alguém em branco
      const saiu = new Promise(function (ok) { fr.addEventListener('load', function () { ok(true); }, { once: true }); });
      doc.getElementById('enviar').click();
      const ok = await Promise.race([saiu, esperar(25000).then(function () { return false; })]);
      if (!ok) return { aula: a, erro: 'o portal não confirmou o salvamento' };
      api('salvarDiario', { aulaId: a.aulaId, campos: { faltasOk: true } }).catch(function () {});
      return { aula: a, ok: true, pres: pres, falt: falt };
    } finally { fr.remove(); }
  }

  // ---- conteúdo de uma data: grava do mesmo jeito que a janela "Sem Registro" do portal grava (mesmo endereço e campos)
  async function conteudo(l, a) {
    if (!a.conteudo) return { semTema: true };
    const url = new URL(l.cont.getAttribute('urlcma') || '/professor/ajax/professor/frequencia/agenda/agendaturma/updatecma.action', location.origin).href;
    const texto = String(a.conteudo).slice(0, 4000);   // o portal guarda até 4000 caracteres
    const r = await fetch(url, { method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
      body: 'agenda=' + encodeURIComponent(l.id) + '&conteudo=' + encodeURIComponent(texto) });
    if (!r.ok) return { erro: 'o portal recusou (' + r.status + ')' };
    // atualiza a agenda na tela, como o portal faz depois de salvar
    l.cont.textContent = texto;
    const sp = document.getElementById('contMin' + l.id); if (sp) sp.textContent = texto;
    api('salvarDiario', { aulaId: a.aulaId, campos: { conteudoOk: true } }).catch(function () {});
    return { ok: true };
  }

  async function rodar(tudo) {
    if (tudo && !confirm('Preencher TUDO de novo: para cada data que bate com o Aula por IA, a frequência e o conteúdo do portal são refeitos e salvos, POR CIMA do que já estiver lá (inclusive o que você editou à mão). Datas sem aula no Aula por IA não são mexidas.\n\nContinuar?')) return;
    if (!cfg.freq && !cfg.cont) { msg('⚠ Em ⚙ Configurar, marque frequência e/ou conteúdo.'); return; }
    if (cfg.meses && !cfg.meses.length) { msg('⚠ Em ⚙ Configurar, marque pelo menos um mês.'); return; }
    parar = false; document.getElementById('aiaLoteParar').disabled = false;
    ['aiaLoteBrancos', 'aiaLoteTudo'].forEach(function (k) { document.getElementById(k).disabled = true; });
    document.getElementById('aiaLoteParar').style.display = '';
    document.getElementById('aiaLoteRel').innerHTML = '';
    const rel = { feitos: [], incompletos: [], erros: [], portalSemAula: [], siteSemPortal: [], pulados: 0 };
    try {
      const site = await api('portalDatas', { disciplina: disciplina });
      await carregarMeses();
      const ls = linhas();
      const doPortal = {};
      ls.forEach(function (l) { doPortal[l.data] = true; });
      const doSite = {};
      site.aulas.forEach(function (s) {
        doSite[s.data] = s;
        const d = s.data.split('/'), am = d[2] + '_' + ('0' + (Number(d[1]) - 1)).slice(-2);   // mesmo formato do portal (mês começa em 0)
        if (!doPortal[s.data] && mesLigado(am)) rel.siteSemPortal.push(s.data + ' (aula ' + s.numero + ')');
      });
      for (let i = 0; i < ls.length && !parar; i++) {
        const l = ls[i];
        if (!doSite[l.data]) { rel.portalSemAula.push(l.data); continue; }
        const precisaFreq = cfg.freq && (tudo || !l.freqLancada), precisaCont = cfg.cont && (tudo || l.contVazio);
        if (!precisaFreq && !precisaCont) { rel.pulados++; continue; }
        msg('Preenchendo ' + l.data + ' (' + (i + 1) + ' de ' + ls.length + ')…');
        const linha = { data: l.data, freq: '', cont: '' };
        let aula = null;
        try {
          if (precisaFreq && l.freqUrl) {
            const f = await frequencia(l);
            aula = f.aula || null;
            if (f.semAula) { rel.portalSemAula.push(l.data); continue; }
            if (f.ok) linha.freq = '✓ frequência (' + f.pres + ' presença(s), ' + f.falt + ' falta(s))';
            else if (f.incompleto) { linha.freq = '⚠ frequência não salva: sem chamada para ' + f.incompleto.join(', '); rel.incompletos.push(l.data + ': ' + f.incompleto.join(', ')); }
            else { linha.freq = '⚠ frequência: ' + f.erro; rel.erros.push(l.data + ' (frequência): ' + f.erro); }
          } else linha.freq = cfg.freq ? 'frequência já lançada (mantida)' : 'frequência não escolhida';
          if (precisaCont && l.cont) {
            if (!aula) aula = await api('portalAula', { disciplina: disciplina, data: l.data, nomes: [] });
            const c = await conteudo(l, aula);
            if (c.ok) linha.cont = '✓ conteúdo';
            else if (c.semTema) linha.cont = '⚠ sem tema no Aula por IA';
            else { linha.cont = '⚠ conteúdo: ' + c.erro; rel.erros.push(l.data + ' (conteúdo): ' + c.erro); }
          } else linha.cont = cfg.cont ? 'conteúdo já preenchido (mantido)' : 'conteúdo não escolhido';
        } catch (e) { linha.freq = linha.freq || '⚠ ' + e.message; rel.erros.push(l.data + ': ' + e.message); }
        rel.feitos.push(linha);
      }
    } catch (e) { rel.erros.push(e.message); }
    ['aiaLoteBrancos', 'aiaLoteTudo'].forEach(function (k) { document.getElementById(k).disabled = false; });
    document.getElementById('aiaLoteParar').style.display = 'none';
    msg(parar ? 'Parado. Abaixo, o que foi feito até agora.' : '✓ Terminou. Atualize a página (F5) para ver a agenda com tudo lançado.');
    relatorio(rel, tudo);
  }

  function relatorio(rel, tudo) {
    const linhasTxt = [
      'Relatório do preenchimento · ' + disciplina + ' · ' + new Date().toLocaleString('pt-BR') + ' · ' + (tudo ? 'tudo de novo' : 'só o que estava em branco') + ' · ' + document.getElementById('aiaLoteResumo').textContent, '',
      'PREENCHIDAS (' + rel.feitos.length + '):'].concat(rel.feitos.map(function (f) { return '- ' + f.data + ': ' + f.freq + ' · ' + f.cont; }),
      ['', 'JÁ ESTAVAM COMPLETAS (mantidas): ' + rel.pulados, '',
        'FALTOU COMPLETAR À MÃO (alunos sem chamada no Aula por IA) (' + rel.incompletos.length + '):'], rel.incompletos.map(function (x) { return '- ' + x; }),
      ['', 'DATAS DO PORTAL SEM AULA NO AULA POR IA (não mexidas) (' + rel.portalSemAula.length + '):'], rel.portalSemAula.map(function (x) { return '- ' + x; }),
      ['', 'AULAS DO AULA POR IA SEM DATA NO PORTAL (' + rel.siteSemPortal.length + '):'], rel.siteSemPortal.map(function (x) { return '- ' + x; }),
      ['', 'ERROS (' + rel.erros.length + '):'], rel.erros.map(function (x) { return '- ' + x; }));
    const texto = linhasTxt.join('\n');
    const box = document.getElementById('aiaLoteRel');
    box.innerHTML = '<pre style="white-space:pre-wrap;max-height:300px;overflow:auto;background:#fff;border:1px solid #c9d2f0;padding:6px;margin:6px 0">' + texto.replace(/[&<>]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]; }) + '</pre>' +
      '<button type="button" id="aiaRelBaixar" style="cursor:pointer">Baixar o relatório (.txt)</button>';
    document.getElementById('aiaRelBaixar').addEventListener('click', function () {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([texto], { type: 'text/plain;charset=utf-8' }));
      a.download = 'relatorio-portal-' + disciplina.replace(/\(.*?\)/g, '').trim().replace(/[^\wÀ-ú]+/g, '-').slice(0, 40) + '-' + new Date().toISOString().slice(0, 10) + '.txt';
      document.body.appendChild(a); a.click(); a.remove();
    });
  }

  document.getElementById('aiaLoteBrancos').addEventListener('click', function () { rodar(false); });
  document.getElementById('aiaLoteTudo').addEventListener('click', function () { rodar(true); });
  document.getElementById('aiaLoteParar').addEventListener('click', function () { parar = true; this.disabled = true; msg('Parando depois desta data…'); });
})();
