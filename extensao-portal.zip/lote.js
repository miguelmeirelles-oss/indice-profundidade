// Agenda da Turma do Portal do Professor: preenche em lote, data por data, a frequência e o conteúdo ministrado
// das aulas que existem no Aula por IA (mesma data). Usa as próprias telas do portal (como se o professor clicasse)
// e salva cada uma. Datas sem aula no Aula por IA não são mexidas nem criadas. No fim, um relatório para baixar.
(function () {
  if (!document.getElementById('accordion')) return;
  const txt = function (el) { return (el && el.textContent || '').replace(/\s+/g, ' ').trim(); };
  const esperar = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  const ate = async function (cond, ms) { const t0 = Date.now(); while (Date.now() - t0 < (ms || 15000)) { try { const v = cond(); if (v) return v; } catch (e) {} await esperar(200); } return null; };
  const api = function (acao, dados) {
    return new Promise(function (ok, falha) {
      chrome.runtime.sendMessage({ tipo: 'api', acao: acao, dados: dados }, function (r) {
        if (r && r.ok) ok(r.resultado);
        else falha(new Error(r && (r.erro === 'SEM_LOGIN' || r.erro === 'SESSAO') ? 'Abra o Aula por IA neste Chrome, já logado, e tente de novo.' : (r && r.erro) || 'Sem conexão com o Aula por IA.'));
      });
    });
  };
  const lbl = Array.prototype.filter.call(document.querySelectorAll('.topo-informacoes span.label'), function (s) { return txt(s).indexOf('Disciplina:') === 0; })[0];
  const disciplina = lbl ? txt(lbl.parentNode).replace('Disciplina:', '').trim() : '';

  // ---- caixa do lote (abaixo do aviso "Aula por IA ligado")
  const caixa = document.createElement('div');
  caixa.style.cssText = 'margin:6px 7px;padding:8px 10px;border:2px solid #1f3a93;border-radius:6px;background:#f6f8ff;font:12px Arial,sans-serif;color:#13235b';
  caixa.innerHTML = '<b>Preencher o semestre todo</b> (frequência e conteúdo ministrado das datas que batem com o Aula por IA; cada uma é salva no portal):<br>' +
    '<button type="button" id="aiaLoteBrancos" style="margin:6px 6px 0 0;cursor:pointer;font-weight:bold">Preencher só o que está em branco</button>' +
    '<button type="button" id="aiaLoteTudo" style="margin:6px 6px 0 0;cursor:pointer">Preencher tudo de novo</button>' +
    '<button type="button" id="aiaLoteParar" style="margin:6px 6px 0 0;cursor:pointer;display:none">Parar</button>' +
    '<button type="button" id="aiaLoteCfgBt" style="margin:6px 0 0 0;cursor:pointer" title="Escolher o que preencher e os meses">⚙ Configurar</button>' +
    '<span id="aiaLoteResumo" style="margin-left:6px;color:#555"></span>' +
    '<div id="aiaLoteCfg" style="display:none;margin-top:8px;padding:8px;border:1px solid #c9d2f0;border-radius:6px;background:#fff"></div>' +
    '<div id="aiaLoteMsg" style="margin-top:6px"></div><div id="aiaLoteRel"></div>';
  const corpo = document.querySelector('.corpopage');
  if (!corpo) return;
  corpo.insertBefore(caixa, corpo.children[1] || null);
  const msg = function (h) { document.getElementById('aiaLoteMsg').innerHTML = h; };
  let parar = false;

  // ---- configuração (fica guardada neste Chrome): o que preencher e quais meses
  let cfg = { freq: true, cont: true, meses: null, semChamada: 'pular' };   // semChamada: pular | presente | falta   // meses: null = todos; senão lista de "2026_10"…
  const meses = function () { return Array.prototype.map.call(document.querySelectorAll('#accordion a.mesesAccordion'), function (a) { return { id: a.getAttribute('anomes'), nome: txt(a) }; }); };
  const mesLigado = function (id) { return !cfg.meses || cfg.meses.indexOf(id) !== -1; };
  const resumoCfg = function () {
    const ms = meses(), lig = ms.filter(function (m) { return mesLigado(m.id); });
    document.getElementById('aiaLoteResumo').textContent = '(' + [cfg.freq ? 'frequência' : '', cfg.cont ? 'conteúdo' : ''].filter(String).join(' e ') +
      (cfg.semChamada !== 'pular' ? ' · sem chamada = ' + cfg.semChamada : '') + ' · ' + (lig.length === ms.length ? 'todos os meses' : lig.map(function (m) { return m.nome.replace(/ \/ \d{4}/, ''); }).join(', ') || 'nenhum mês') + ')';
  };
  const desenharCfg = function () {
    const box = document.getElementById('aiaLoteCfg');
    box.innerHTML = '<b>O que preencher</b><br>' +
      '<label style="cursor:pointer"><input type="checkbox" id="aiaCfgFreq"' + (cfg.freq ? ' checked' : '') + '> Frequência (presenças e faltas)</label><br>' +
      '<label style="cursor:pointer"><input type="checkbox" id="aiaCfgCont"' + (cfg.cont ? ' checked' : '') + '> Conteúdo ministrado (tema da aula)</label><br>' +
      '<b style="display:inline-block;margin-top:6px">Meses</b> <a href="#" id="aiaCfgTodos" style="font-size:11px">todos</a> · <a href="#" id="aiaCfgNenhum" style="font-size:11px">nenhum</a><br>' +
      meses().map(function (m) { return '<label style="cursor:pointer;margin-right:10px"><input type="checkbox" data-aiames="' + m.id + '"' + (mesLigado(m.id) ? ' checked' : '') + '> ' + m.nome + '</label>'; }).join('') +
      '<br><b style="display:inline-block;margin-top:6px">Aluno sem chamada no Aula por IA</b> <span style="color:#555">(ex.: entrou na turma depois da aula)</span><br>' +
      [['pular', 'Salvar os outros e deixar em branco (eu completo à mão; aparece no relatório)'], ['presente', 'Marcar presença e salvar'], ['falta', 'Marcar falta e salvar']].map(function (o) {
        return '<label style="cursor:pointer;display:block"><input type="radio" name="aiaCfgSem" value="' + o[0] + '"' + (cfg.semChamada === o[0] ? ' checked' : '') + '> ' + o[1] + '</label>';
      }).join('') +
      '<div style="margin-top:6px"><button type="button" id="aiaCfgOk" style="cursor:pointer">OK</button></div>';
    const ler = function () {
      cfg.freq = document.getElementById('aiaCfgFreq').checked; cfg.cont = document.getElementById('aiaCfgCont').checked;
      const sem = box.querySelector('input[name="aiaCfgSem"]:checked'); cfg.semChamada = sem ? sem.value : 'pular';
      const marc = Array.prototype.filter.call(box.querySelectorAll('[data-aiames]'), function (c) { return c.checked; }).map(function (c) { return c.dataset.aiames; });
      cfg.meses = marc.length === meses().length ? null : marc;
      try { chrome.storage.local.set({ cfgLote: cfg }); } catch (e) {}
      resumoCfg();
    };
    box.querySelectorAll('input').forEach(function (c) { c.addEventListener('change', ler); });
    document.getElementById('aiaCfgTodos').addEventListener('click', function (e) { e.preventDefault(); box.querySelectorAll('[data-aiames]').forEach(function (c) { c.checked = true; }); ler(); });
    document.getElementById('aiaCfgNenhum').addEventListener('click', function (e) { e.preventDefault(); box.querySelectorAll('[data-aiames]').forEach(function (c) { c.checked = false; }); ler(); });
    document.getElementById('aiaCfgOk').addEventListener('click', function () { box.style.display = 'none'; });
  };
  document.getElementById('aiaLoteCfgBt').addEventListener('click', function () {
    const box = document.getElementById('aiaLoteCfg');
    if (box.style.display === 'none') { desenharCfg(); box.style.display = ''; } else box.style.display = 'none';
  });
  try { chrome.storage.local.get('cfgLote').then(function (g) { if (g.cfgLote) cfg = Object.assign(cfg, g.cfgLote); resumoCfg(); }); } catch (e) { resumoCfg(); }
  resumoCfg();

  // ---- abre todos os meses (o portal carrega cada mês quando a gente clica nele)
  async function carregarMeses() {
    const links = Array.prototype.slice.call(document.querySelectorAll('#accordion a.mesesAccordion'));
    for (let i = 0; i < links.length; i++) {
      const a = links[i], id = 'conteudoAccordion' + a.getAttribute('ano') + a.getAttribute('mes');
      if (!mesLigado(a.getAttribute('anomes')) || document.getElementById(id)) continue;
      msg('Abrindo ' + txt(a) + '…');
      a.parentNode.click();
      await ate(function () { return document.getElementById(id); }, 20000);
      await esperar(300);
    }
  }
  function linhas() {
    return Array.prototype.filter.call(document.querySelectorAll('#accordion tr.row[idagenda]'), function (tr) { return mesLigado(tr.getAttribute('dataaccordion')); }).map(function (tr) {
      const am = String(tr.getAttribute('dataaccordion') || '').split('_');   // "2026_10" = novembro (mês começa em 0)
      const mes = ('0' + (Number(am[1]) + 1)).slice(-2), dia = ('0' + Number(tr.getAttribute('data'))).slice(-2);
      const tds = tr.querySelectorAll('td'), cont = tr.querySelector('a.add-cont-min');
      return { tr: tr, id: tr.getAttribute('idagenda'), data: dia + '/' + mes + '/' + am[0],
        // com a frequência já lançada a setinha verde some: a tela continua no mesmo endereço, pelo número da aula
        freqUrl: (tr.querySelector('a[title="Lançamento de Frequência"]') || {}).href || new URL('/professor/professor/frequencia/lancamento/horaaula/horaaula.action?agenda=' + tr.getAttribute('idagenda') + '&indexAba=0', location.origin).href,
        freqLancada: !/não lançada/i.test(txt(tds[3])), cont: cont, contVazio: !cont || txt(cont) === 'Sem Registro' };
    });
  }

  // ---- frequência de uma data: lê a tela do portal, monta o mesmo formulário do botão Salvar e envia
  const situacao = function (q) {
    const c = q.className;
    if (c.indexOf('aluno-ausente-local') !== -1) return 'falta';
    if (c.indexOf('aluno-presente-local') !== -1 || c.indexOf('aluno-ad-local') !== -1) return 'presente';
    return 'branco';
  };
  // lê a tela de frequência de uma data (sem abrir), do jeito que o portal a manda para o navegador
  async function lerTelaFrequencia(url) {
    const r = await fetch(url, { credentials: 'same-origin' });
    if (!r.ok) return null;
    const doc = new DOMParser().parseFromString(await r.text(), 'text/html');
    return doc.getElementById('horaAulaCommand') ? doc : null;
  }
  async function frequencia(l) {
    const doc = await lerTelaFrequencia(l.freqUrl);
    if (!doc) return { erro: 'a tela de frequência não abriu (a sessão do portal pode ter expirado: entre de novo no portal)' };
    const form = doc.getElementById('horaAulaCommand');
    const cartoes = Array.prototype.slice.call(form.querySelectorAll('div.aluno'));
    const nome = function (c) { return txt(c.querySelector('a.nome-aluno')); };
    const a = await api('portalAula', { disciplina: disciplina, data: l.data, nomes: cartoes.map(nome) });
    if (!a.encontrada) return { semAula: true };
    // situação final de cada quadradinho: o que vem do Aula por IA; justificada / não editável fica como o portal mandou
    const periodos = Array.prototype.map.call(doc.querySelectorAll('.check-periodo[periodo]'), function (c) { return c.getAttribute('periodo'); });
    const branco = {}, campos = [], totais = { pres: {}, falt: {} }, pelaRegra = {};
    ['agenda', 'turma', 'indexAba'].forEach(function (n) { const i = form.querySelector('input[name="' + n + '"]'); if (i) campos.push([n, i.value]); });
    periodos.forEach(function (p, k) {
      Array.prototype.forEach.call(form.querySelectorAll('.periodoLocal[periodo="' + p + '"]'), function (q) {
        const c = q.closest('div.aluno'), n = nome(c), alvo = a.estados[n];
        let sit = situacao(q);
        if (!q.classList.contains('aluno-ad-local') && (alvo === 'presente' || alvo === 'falta')) sit = alvo;
        if (sit === 'branco' && cfg.semChamada !== 'pular' && !q.classList.contains('aluno-ad-local')) { sit = cfg.semChamada; pelaRegra[n] = true; }
        if (sit === 'branco') { branco[n] = true; return; }
        if (sit === 'falta') totais.falt[n] = true; else totais.pres[n] = true;
        campos.push(['horasAula[' + q.getAttribute('aluno') + '][' + k + '].periodo', p]);
        campos.push(['horasAula[' + q.getAttribute('aluno') + '][' + k + '].presente', sit === 'presente' ? 'true' : 'false']);
      });
    });
    // quem não tem chamada fica de fora do envio (em branco no portal); se ninguém bateu, não há o que salvar
    const emBranco = Object.keys(branco);
    if (!Object.keys(totais.pres).length && !Object.keys(totais.falt).length) return { aula: a, incompleto: emBranco };
    // envia o mesmo formulário que o botão "Salvar" do portal envia
    const destino = new URL(form.getAttribute('action'), l.freqUrl).href;
    const envio = await fetch(destino, { method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: campos.map(function (x) { return encodeURIComponent(x[0]) + '=' + encodeURIComponent(x[1]); }).join('&') });
    if (!envio.ok) return { aula: a, erro: 'o portal recusou o salvamento (' + envio.status + ')' };
    // confere relendo a tela: quem foi enviado tem de estar gravado; quem ficou de fora, como ficou
    const depois = await lerTelaFrequencia(l.freqUrl);
    const agora = {};
    if (depois) Array.prototype.forEach.call(depois.querySelectorAll('#horaAulaCommand div.aluno'), function (c) {
      agora[nome(c)] = Array.prototype.map.call(c.querySelectorAll('td.periodos > div'), situacao);
    });
    const naoGravou = Object.keys(totais.pres).concat(Object.keys(totais.falt)).filter(function (n, i, l) { return l.indexOf(n) === i && agora[n] && agora[n].indexOf('branco') !== -1; });
    if (naoGravou.length) return { aula: a, erro: 'o portal não gravou' + (emBranco.length ? ' (talvez não aceite salvar com alguém em branco: use a regra presença/falta no ⚙)' : '') };
    const viraramFalta = emBranco.filter(function (n) { return agora[n] && agora[n].indexOf('falta') !== -1; });   // o portal pode marcar falta para quem ficou de fora
    if (!emBranco.length) api('salvarDiario', { aulaId: a.aulaId, campos: { faltasOk: true } }).catch(function () {});
    return { aula: a, ok: true, emBranco: emBranco, viraramFalta: viraramFalta, pelaRegra: Object.keys(pelaRegra), pres: Object.keys(totais.pres).filter(function (n) { return !totais.falt[n]; }).length, falt: Object.keys(totais.falt).length };
  }

  // ---- conteúdo de uma data: grava do mesmo jeito que a janela "Sem Registro" do portal grava (mesmo endereço e campos)
  async function conteudo(l, a) {
    if (!a.conteudo) return { semTema: true };
    const url = new URL(l.cont.getAttribute('urlcma') || '/professor/ajax/professor/frequencia/agenda/agendaturma/updatecma.action', location.origin).href;
    const texto = String(a.conteudo).slice(0, 4000);   // o portal guarda até 4000 caracteres
    const r = await fetch(url, { method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
      body: 'agenda=' + encodeURIComponent(l.id) + '&conteudo=' + encodeURIComponent(texto) });
    if (!r.ok) return { erro: 'o portal recusou (' + r.status + ')' };
    // atualiza a agenda na tela, como o portal faz depois de salvar
    l.cont.textContent = texto;
    const sp = document.getElementById('contMin' + l.id); if (sp) sp.textContent = texto;
    api('salvarDiario', { aulaId: a.aulaId, campos: { conteudoOk: true } }).catch(function () {});
    return { ok: true };
  }

  async function rodar(tudo) {
    if (tudo && !confirm('Preencher TUDO de novo: para cada data que bate com o Aula por IA, a frequência e o conteúdo do portal são refeitos e salvos, POR CIMA do que já estiver lá (inclusive o que você editou à mão). Datas sem aula no Aula por IA não são mexidas.\n\nContinuar?')) return;
    if (!cfg.freq && !cfg.cont) { msg('⚠ Em ⚙ Configurar, marque frequência e/ou conteúdo.'); return; }
    if (cfg.meses && !cfg.meses.length) { msg('⚠ Em ⚙ Configurar, marque pelo menos um mês.'); return; }
    parar = false; document.getElementById('aiaLoteParar').disabled = false;
    ['aiaLoteBrancos', 'aiaLoteTudo'].forEach(function (k) { document.getElementById(k).disabled = true; });
    document.getElementById('aiaLoteParar').style.display = '';
    document.getElementById('aiaLoteRel').innerHTML = '';
    const rel = { feitos: [], incompletos: [], erros: [], portalSemAula: [], siteSemPortal: [], pulados: 0 };
    try {
      const site = await api('portalDatas', { disciplina: disciplina });
      await carregarMeses();
      const ls = linhas();
      const doPortal = {};
      ls.forEach(function (l) { doPortal[l.data] = true; });
      const doSite = {};
      site.aulas.forEach(function (s) {
        doSite[s.data] = s;
        const d = s.data.split('/'), am = d[2] + '_' + ('0' + (Number(d[1]) - 1)).slice(-2);   // mesmo formato do portal (mês começa em 0)
        if (!doPortal[s.data] && mesLigado(am)) rel.siteSemPortal.push(s.data + ' (aula ' + s.numero + ')');
      });
      for (let i = 0; i < ls.length && !parar; i++) {
        const l = ls[i];
        if (!doSite[l.data]) { rel.portalSemAula.push(l.data); continue; }
        const precisaFreq = cfg.freq && (tudo || !l.freqLancada), precisaCont = cfg.cont && (tudo || l.contVazio);
        if (!precisaFreq && !precisaCont) { rel.pulados++; continue; }
        msg('Preenchendo ' + l.data + ' (' + (i + 1) + ' de ' + ls.length + ')…');
        const linha = { data: l.data, freq: '', cont: '' };
        let aula = null;
        try {
          if (precisaFreq && l.freqUrl) {
            const f = await frequencia(l);
            aula = f.aula || null;
            if (f.semAula) { rel.portalSemAula.push(l.data); continue; }
            if (f.ok) {
              linha.freq = '✓ frequência (' + f.pres + ' presença(s), ' + f.falt + ' falta(s))' + (f.pelaRegra.length ? ' · sem chamada, marcado como ' + cfg.semChamada + ': ' + f.pelaRegra.join(', ') : '');
              if (f.emBranco.length) {
                const quem = f.emBranco.map(function (n) { return n + (f.viraramFalta.indexOf(n) !== -1 ? ' (o portal marcou FALTA: confira)' : ' (em branco)'); });
                linha.freq += ' · ⚠ sem chamada: ' + quem.join(', ');
                linha.semMarcar = f.emBranco;
                rel.incompletos.push(l.data + ': ' + quem.join(', '));
              }
            }
            else if (f.incompleto) { linha.semMarcar = f.incompleto; linha.freq = '⚠ frequência não salva: sem chamada para ' + f.incompleto.join(', '); rel.incompletos.push(l.data + ': ' + f.incompleto.join(', ')); }
            else { linha.freq = '⚠ frequência: ' + f.erro; rel.erros.push(l.data + ' (frequência): ' + f.erro); }
          } else linha.freq = cfg.freq ? 'frequência já lançada (mantida)' : 'frequência não escolhida';
          if (precisaCont && l.cont) {
            if (!aula) aula = await api('portalAula', { disciplina: disciplina, data: l.data, nomes: [] });
            const c = await conteudo(l, aula);
            if (c.ok) linha.cont = '✓ conteúdo';
            else if (c.semTema) linha.cont = '⚠ sem tema no Aula por IA';
            else { linha.cont = '⚠ conteúdo: ' + c.erro; rel.erros.push(l.data + ' (conteúdo): ' + c.erro); }
          } else linha.cont = cfg.cont ? 'conteúdo já preenchido (mantido)' : 'conteúdo não escolhido';
        } catch (e) { linha.freq = linha.freq || '⚠ ' + e.message; rel.erros.push(l.data + ': ' + e.message); }
        rel.feitos.push(linha);
        // guarda no Diário do portal do Aula por IA o que foi feito nesta data (e quem ficou sem marcar)
        const idAula = aula && aula.aulaId;
        if (idAula) api('salvarDiario', { aulaId: idAula, campos: { portal: { freq: linha.freq, cont: linha.cont, semMarcar: linha.semMarcar || [] } } }).catch(function () {});
      }
    } catch (e) { rel.erros.push(e.message); }
    ['aiaLoteBrancos', 'aiaLoteTudo'].forEach(function (k) { document.getElementById(k).disabled = false; });
    document.getElementById('aiaLoteParar').style.display = 'none';
    msg(parar ? 'Parado. Abaixo, o que foi feito até agora.' : '✓ Terminou. Atualize a página (F5) para ver a agenda com tudo lançado.');
    relatorio(rel, tudo);
  }

  function relatorio(rel, tudo) {
    const linhasTxt = [
      'Relatório do preenchimento · ' + disciplina + ' · ' + new Date().toLocaleString('pt-BR') + ' · ' + (tudo ? 'tudo de novo' : 'só o que estava em branco') + ' · ' + document.getElementById('aiaLoteResumo').textContent, '',
      'PREENCHIDAS (' + rel.feitos.length + '):'].concat(rel.feitos.map(function (f) { return '- ' + f.data + ': ' + f.freq + ' · ' + f.cont; }),
      ['', 'JÁ ESTAVAM COMPLETAS (mantidas): ' + rel.pulados, '',
        'FALTOU COMPLETAR À MÃO (alunos sem chamada no Aula por IA) (' + rel.incompletos.length + '):'], rel.incompletos.map(function (x) { return '- ' + x; }),
      ['', 'DATAS DO PORTAL SEM AULA NO AULA POR IA (não mexidas) (' + rel.portalSemAula.length + '):'], rel.portalSemAula.map(function (x) { return '- ' + x; }),
      ['', 'AULAS DO AULA POR IA SEM DATA NO PORTAL (' + rel.siteSemPortal.length + '):'], rel.siteSemPortal.map(function (x) { return '- ' + x; }),
      ['', 'ERROS (' + rel.erros.length + '):'], rel.erros.map(function (x) { return '- ' + x; }));
    const texto = linhasTxt.join('\n');
    const box = document.getElementById('aiaLoteRel');
    box.innerHTML = '<pre style="white-space:pre-wrap;max-height:300px;overflow:auto;background:#fff;border:1px solid #c9d2f0;padding:6px;margin:6px 0">' + texto.replace(/[&<>]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]; }) + '</pre>' +
      '<button type="button" id="aiaRelBaixar" style="cursor:pointer">Baixar o relatório (.txt)</button>';
    document.getElementById('aiaRelBaixar').addEventListener('click', function () {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([texto], { type: 'text/plain;charset=utf-8' }));
      a.download = 'relatorio-portal-' + disciplina.replace(/\(.*?\)/g, '').trim().replace(/[^\wÀ-ú]+/g, '-').slice(0, 40) + '-' + new Date().toISOString().slice(0, 10) + '.txt';
      document.body.appendChild(a); a.click(); a.remove();
    });
  }

  document.getElementById('aiaLoteBrancos').addEventListener('click', function () { rodar(false); });
  document.getElementById('aiaLoteTudo').addEventListener('click', function () { rodar(true); });
  document.getElementById('aiaLoteParar').addEventListener('click', function () { parar = true; this.disabled = true; msg('Parando depois desta data…'); });
})();
