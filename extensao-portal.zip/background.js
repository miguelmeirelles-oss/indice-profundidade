// Fala com o servidor do Aula por IA em nome da página do portal (a página do portal não pode chamar outro site).
const BACKEND = 'https://script.google.com/macros/s/AKfycbyK-YXssnq1iBhqVAPMl4BlccH7eI1-0U9EqqOKV7vgK0qJSe9rgo51XZKxK45V2gOj/exec';

chrome.runtime.onMessage.addListener(function (msg, remetente, responder) {
  if (msg && msg.tipo === 'token') {
    // o Aula por IA aberto no navegador entrega o login do professor (fica só neste Chrome)
    chrome.storage.local.set({ token: msg.token, em: Date.now() });
    responder({ ok: true });
    return false;
  }
  if (msg && msg.tipo === 'api') {
    chrome.storage.local.get('token').then(function (g) {
      if (!g.token) { responder({ ok: false, erro: 'SEM_LOGIN' }); return; }
      const dados = Object.assign({}, msg.dados || {}, { token: g.token });
      return fetch(BACKEND, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ acao: msg.acao, dados: dados }) })
        .then(function (r) { return r.json(); })
        .then(function (j) { responder(j.ok ? { ok: true, resultado: j.resultado } : { ok: false, erro: j.erro }); });
    }).catch(function (e) { responder({ ok: false, erro: 'Sem conexão com o Aula por IA (' + e.message + ').' }); });
    return true;   // responde depois (assíncrono)
  }
  return false;
});
