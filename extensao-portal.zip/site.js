// No site do Aula por IA: pega o login do professor que já está aberto e guarda para a extensão usar no portal.
(function () {
  let token = '';
  try { token = sessionStorage.getItem('ip_token') || localStorage.getItem('ip_token') || ''; } catch (e) { /* sem acesso */ }
  if (token) chrome.runtime.sendMessage({ tipo: 'token', token: token });
})();
